function formatBytes(bytes) {
  if (!Number.isFinite(bytes)) return "غير معروف";
  const units = ["بايت", "KB", "MB", "GB"];
  let size = bytes, index = 0;
  while (size >= 1024 && index < units.length - 1) { size /= 1024; index++; }
  return `${size.toFixed(index === 0 ? 0 : 2)} ${units[index]}`;
}

function readDuration(file) {
  return new Promise(resolve => {
    const url = URL.createObjectURL(file);
    const video = document.createElement("video");
    video.preload = "metadata";
    video.onloadedmetadata = () => {
      const result = {
        duration: Number.isFinite(video.duration) ? `${video.duration.toFixed(2)} ثانية` : "غير متاحة",
        dimensions: video.videoWidth && video.videoHeight ? `${video.videoWidth} × ${video.videoHeight}` : "غير متاحة"
      };
      URL.revokeObjectURL(url);
      resolve(result);
    };
    video.onerror = () => { URL.revokeObjectURL(url); resolve({duration:"تعذر قراءتها", dimensions:"غير متاحة"}); };
    video.src = url;
  });
}

export async function run({ file }) {
  if (!file) throw new Error("اختر فيديو أولًا.");
  const metadata = await readDuration(file);
  return {
    title: "معلومات الفيديو",
    text: [
      `اسم الملف: ${file.name}`,
      `النوع: ${file.type || "غير معروف"}`,
      `الحجم: ${formatBytes(file.size)}`,
      `المدة: ${metadata.duration}`,
      `الأبعاد: ${metadata.dimensions}`,
      "",
      "تمت قراءة المعلومات داخل المتصفح."
    ].join("\n")
  };
}
