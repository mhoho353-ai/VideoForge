/*
 * سجل الأدوات: أضف أو احذف عنصرًا من مصفوفة TOOLS لتعديل قائمة الأدوات.
 * كل أداة مستقلة في ملف داخل assets/js/tools/.
 * لا تضع أكوادًا من مصادر غير موثوقة هنا.
 */
export const TOOLS = [
  {
    id: "video-info",
    name: "معلومات الفيديو",
    description: "عرض اسم الملف ونوعه وحجمه ومدة الفيديو إن أمكن.",
    icon: "ⓘ",
    module: "./video-info.js",
    needsVideo: true,
    enabled: true
  },
  {
    id: "extract-audio",
    name: "استخراج الصوت",
    description: "هيكل جاهز لإضافة استخراج الصوت باستخدام محرك متصفح مناسب.",
    icon: "♫",
    module: "./extract-audio.js",
    needsVideo: true,
    enabled: false
  },
  {
    id: "remove-silence",
    name: "حذف الصمت",
    description: "أضف هنا أداة كشف الصمت وقص المقاطع الصامتة.",
    icon: "✂",
    module: "./remove-silence.js",
    needsVideo: true,
    enabled: false
  },
  {
    id: "speech-to-text",
    name: "تحويل الكلام إلى نص",
    description: "هيكل لربط محرك تفريغ صوتي أو واجهة API.",
    icon: "CC",
    module: "./speech-to-text.js",
    needsVideo: true,
    enabled: false
  }
];

export function getEnabledTools() {
  return TOOLS.filter(tool => tool.enabled);
}
