import { getEnabledTools, TOOLS } from "./tools/registry.js";
import { TaskQueue } from "./task-queue.js";

const $ = selector => document.querySelector(selector);
const fileInput = $("#videoInput");
const dropZone = $("#dropZone");
const fileDetails = $("#fileDetails");
const videoPreview = $("#videoPreview");
const clearVideoButton = $("#clearVideo");
const toolsList = $("#toolsList");
const toolSearch = $("#toolSearch");
const queueList = $("#queueList");
const queueEmpty = $("#queueEmpty");
const toast = $("#toast");
const queue = new TaskQueue();

let currentFile = null;
let toastTimer;

function notify(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove("show"), 2800);
}

function setFile(file) {
  if (!file) return;
  if (!file.type.startsWith("video/")) {
    notify("اختر ملف فيديو صالحًا.");
    return;
  }
  if (currentFile && videoPreview.src.startsWith("blob:")) URL.revokeObjectURL(videoPreview.src);
  currentFile = file;
  const url = URL.createObjectURL(file);
  videoPreview.src = url;
  videoPreview.classList.remove("hidden");
  fileDetails.textContent = `${file.name} — ${(file.size / (1024 * 1024)).toFixed(2)} MB`;
  fileDetails.classList.remove("hidden");
  clearVideoButton.classList.remove("hidden");
  renderTools();
}

function clearFile() {
  if (videoPreview.src.startsWith("blob:")) URL.revokeObjectURL(videoPreview.src);
  videoPreview.pause();
  videoPreview.removeAttribute("src");
  videoPreview.load();
  currentFile = null;
  fileInput.value = "";
  fileDetails.classList.add("hidden");
  videoPreview.classList.add("hidden");
  clearVideoButton.classList.add("hidden");
  renderTools();
}

function renderTools() {
  const query = toolSearch.value.trim().toLocaleLowerCase();
  const tools = getEnabledTools().filter(tool =>
    `${tool.name} ${tool.description}`.toLocaleLowerCase().includes(query)
  );
  $("#toolCount").textContent = `${getEnabledTools().length} أدوات مفعّلة`;
  toolsList.replaceChildren();
  if (!tools.length) {
    const empty = document.createElement("p");
    empty.className = "muted";
    empty.textContent = "لا توجد أدوات مطابقة.";
    toolsList.append(empty);
    return;
  }
  for (const tool of tools) {
    const card = document.createElement("article");
    card.className = "tool-card";
    const icon = document.createElement("span");
    icon.className = "tool-icon";
    icon.textContent = tool.icon;
    const copy = document.createElement("div");
    copy.className = "tool-copy";
    const title = document.createElement("strong");
    title.textContent = tool.name;
    const desc = document.createElement("p");
    desc.textContent = tool.description;
    copy.append(title, desc);
    const button = document.createElement("button");
    button.className = "add-task";
    button.type = "button";
    button.textContent = "إضافة للطابور";
    button.disabled = tool.needsVideo && !currentFile;
    button.addEventListener("click", () => {
      if (tool.needsVideo && !currentFile) { notify("اختر فيديو أولًا."); return; }
      queue.add(tool, currentFile);
      notify(`أُضيفت «${tool.name}» إلى الطابور.`);
    });
    card.append(icon, copy, button);
    toolsList.append(card);
  }
}

function renderQueue(tasks) {
  queueList.replaceChildren();
  queueEmpty.classList.toggle("hidden", tasks.length > 0);
  for (const task of tasks) {
    const row = document.createElement("article");
    row.className = "task-row";
    const dot = document.createElement("span");
    dot.className = `task-status ${task.status === "running" ? "running" : task.status}`;
    const info = document.createElement("div");
    info.className = "task-info";
    const title = document.createElement("strong");
    title.textContent = task.toolName;
    const details = document.createElement("small");
    const statusLabels = {queued:"بانتظار التشغيل", running:"جارٍ التنفيذ", completed:"اكتملت", failed:"فشلت"};
    details.textContent = `${statusLabels[task.status] || task.status} · ${task.fileName || "بدون ملف"} · ${task.createdAt}`;
    info.append(title, details);
    const actions = document.createElement("div");
    actions.className = "task-actions";
    if (task.status === "queued") {
      const runButton = document.createElement("button");
      runButton.textContent = "تشغيل";
      runButton.addEventListener("click", () => runTask(task.id));
      actions.append(runButton);
    }
    if (task.result?.text) {
      const resultButton = document.createElement("button");
      resultButton.textContent = "عرض النتيجة";
      resultButton.addEventListener("click", () => showResult(task.result));
      actions.append(resultButton);
    }
    if (task.status === "failed" && task.error) {
      const errorButton = document.createElement("button");
      errorButton.textContent = "عرض الخطأ";
      errorButton.addEventListener("click", () => notify(task.error));
      actions.append(errorButton);
    }
    const removeButton = document.createElement("button");
    removeButton.textContent = "حذف";
    removeButton.addEventListener("click", () => queue.remove(task.id));
    actions.append(removeButton);
    row.append(dot, info, actions);
    queueList.append(row);
  }
}

async function runTask(taskId) {
  const task = queue.getAll().find(item => item.id === taskId);
  if (!task) return;
  const tool = TOOLS.find(item => item.id === task.toolId);
  if (!tool) { queue.update(taskId, {status:"failed", error:"الأداة غير موجودة في سجل الأدوات."}); return; }
  if (tool.needsVideo && (!currentFile || currentFile.name !== task.fileName)) {
    queue.update(taskId, {status:"failed", error:"الفيديو المحدد لم يعد متاحًا. أعد اختياره ثم أضف المهمة من جديد."});
    return;
  }
  queue.update(taskId, {status:"running", error:null});
  try {
    const module = await import(tool.module);
    if (typeof module.run !== "function") throw new Error("ملف الأداة يجب أن يصدّر دالة run.");
    const result = await module.run({file: currentFile});
    queue.update(taskId, {status:"completed", result});
    notify(`اكتملت أداة «${tool.name}».`);
  } catch (error) {
    queue.update(taskId, {status:"failed", error: error?.message || "حدث خطأ غير معروف."});
  }
}

function showResult(result) {
  const overlay = document.createElement("dialog");
  overlay.className = "result-dialog";
  const title = document.createElement("h3");
  title.textContent = result.title || "نتيجة المهمة";
  const pre = document.createElement("pre");
  pre.textContent = result.text || JSON.stringify(result, null, 2);
  const close = document.createElement("button");
  close.className = "button button-primary";
  close.textContent = "إغلاق";
  close.addEventListener("click", () => overlay.close());
  overlay.append(title, pre, close);
  document.body.append(overlay);
  overlay.addEventListener("close", () => overlay.remove(), {once:true});
  overlay.showModal();
}

fileInput.addEventListener("change", () => setFile(fileInput.files?.[0]));
clearVideoButton.addEventListener("click", clearFile);
toolSearch.addEventListener("input", renderTools);
$("#clearQueue").addEventListener("click", () => queue.clearFinished());
dropZone.addEventListener("dragover", event => { event.preventDefault(); dropZone.classList.add("dragging"); });
dropZone.addEventListener("dragleave", () => dropZone.classList.remove("dragging"));
dropZone.addEventListener("drop", event => {
  event.preventDefault(); dropZone.classList.remove("dragging");
  setFile(event.dataTransfer.files?.[0]);
});
queue.subscribe(renderQueue);
renderTools();
