export class TaskQueue {
  constructor() { this.tasks = []; this.listeners = new Set(); }
  subscribe(listener) { this.listeners.add(listener); listener(this.getAll()); return () => this.listeners.delete(listener); }
  emit() { const snapshot = this.getAll(); this.listeners.forEach(listener => listener(snapshot)); }
  getAll() { return this.tasks.map(task => ({...task})); }
  add(tool, file) {
    const task = {
      id: globalThis.crypto?.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      toolId: tool.id, toolName: tool.name, status: "queued",
      fileName: file?.name || "", createdAt: new Date().toLocaleTimeString("ar-EG"),
      result: null, error: null
    };
    this.tasks.unshift(task); this.emit(); return task.id;
  }
  update(id, changes) {
    const task = this.tasks.find(item => item.id === id);
    if (task) { Object.assign(task, changes); this.emit(); }
  }
  remove(id) { this.tasks = this.tasks.filter(task => task.id !== id); this.emit(); }
  clearFinished() { this.tasks = this.tasks.filter(task => !["completed", "failed"].includes(task.status)); this.emit(); }
}
